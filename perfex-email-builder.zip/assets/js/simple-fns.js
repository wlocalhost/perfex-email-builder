// $(document).ready(function() {
//   console.log(new URLSearchParams(location.href));
// });
