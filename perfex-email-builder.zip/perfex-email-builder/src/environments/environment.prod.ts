export const environment = {
  globalVariable: (window as any).GlobalVariable,
  production: true
};
